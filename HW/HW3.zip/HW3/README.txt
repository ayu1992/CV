Name: An An Yu
Student ID : 5116372
Email: yuxx0535@umn.edu

Running program:
Suggest running under my 'HW3' folder because some images will be saved to its subfolders (q1,q2,q3,q4).

Execution:
execute hw3_script

For question 2, adjust Thigh in line 24 (hw3_script.m)
For question 3,
    circle: adjust line 5,10 and 16 inside detect_blobs.m, and then uncomment line 32