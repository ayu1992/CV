Name: An An Yu
Student ID: 5116372
Email: yuxx0535@umn.edu

Execute:
rotate_image(input_image, theta, p0)
>>  rotate_image('cameraman.tif',45,[40;100]);
using imwarp
>>  withImwarp('cameraman.tif', 60);	